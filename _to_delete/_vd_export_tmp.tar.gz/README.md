# Viewport Doctor

A Next.js/React web app that opens your app's pages at several screen
sizes in a real headless browser and flags responsive-layout bugs -
horizontal scrolling, clipped buttons, overlapping elements, text that
overflows its box, oversized modals, and images wider than their
container - the kind of bug that only shows up on a phone or a specific
window width, and that nobody notices until a user reports it. Point it
at a URL, pick which screen sizes to check, click **Run scan**, and get a
highlighted screenshot per page × viewport, plus a suggested fix for each
issue, instead of manually resizing devtools on every route.

Every suggested fix is cross-checked against every viewport you scanned:
if the same bug is already fixed at some sizes, the suggestion says so
explicitly and tells you to scope the fix (e.g. to a `max-width` media
query) instead of changing the rule globally - so fixing what's broken on
a phone doesn't quietly break what already works on a laptop.

> This tool detects issues and suggests how to fix them in plain-language,
> rule-based guidance - it does not modify your source code for you. See
> "What this doesn't do" below for why an automatic code-fixing version
> (one that actually edits your files) is a meaningfully bigger, separate
> project.

## Problem it solves, and who it's for

Responsive bugs are notoriously easy to miss in day-to-day development,
because most developers build and check their own work at one screen
size (their own monitor) and only occasionally resize the browser or
open devtools' device toolbar. A card row that doesn't wrap, a modal
that's wider than a phone screen, a badge that overlaps a button label
below some breakpoint - none of these break the build, none of them throw
a console error, and all of them are only visible if someone actually
looks at that specific page at that specific width.

**Target role:** Frontend Developer (also useful for QA). Run it across
your app's key pages at a handful of screen sizes before a release,
instead of manually resizing devtools page by page.

## How it works

1. Enter a base URL and the page paths to check, and pick which viewport
   sizes to test (Mobile/Tablet/Laptop/Desktop presets, or add a custom
   size) - or click **Load demo example** to try it instantly against the
   bundled demo page.
2. The React frontend posts that list to a Next.js API route
   (`app/api/scan`), which runs on the server.
3. For every page × viewport combination, the server launches a real
   headless Chromium browser (via [Playwright](https://playwright.dev))
   at that exact window size, navigates to the page, and runs six DOM
   measurement checks directly in the page's own JS context (real
   `getBoundingClientRect()`/`scrollWidth` values, not a screenshot diff
   or a guess).
4. Every flagged element gets a highlighted box drawn around it, then the
   server captures a full-page screenshot and removes the highlight
   again - so what you see is the actual page, with the actual problem
   circled.
5. The API also cross-references every issue against every viewport
   scanned for that page (same check + same offending element = the same
   underlying bug, see "Suggested fixes" below) and attaches a
   rule-based, plain-language fix suggestion - noting explicitly which
   sizes are already fine, so the advice can tell you to scope the fix
   instead of applying it globally.
6. The API returns per-page, per-viewport results (plus the fix
   suggestions), and the React UI renders them as a page → viewport tab
   layout: pick a viewport pill to see its issue list, each with its
   suggested fix, and the highlighted screenshot.

## The six checks

| Check | What it catches |
|---|---|
| `horizontal-overflow` | The page is wider than the viewport (causes horizontal scrolling) - reports the outermost element responsible. |
| `clipped-element` | A button, link, or input is cut off by an ancestor with `overflow: hidden`. |
| `overlapping-elements` | Two interactive elements (buttons/links/inputs) that aren't ancestor/descendant of each other overlap by more than 30% of the smaller one's area. |
| `text-overflow` | Text content wider than its own box, with no wrap or ellipsis handling. |
| `oversized-modal` | A `<dialog>`/`[role="dialog"]`/`.modal`-ish element bigger than the viewport itself. |
| `overflowing-image` | An `<img>` wider than its parent container (usually a missing `max-width: 100%`). |

All six are real DOM geometry checks (no visual/pixel-diffing), so there
are no false positives from anti-aliasing or font rendering differences -
if a check fires, the measured overflow/overlap is real.

## Suggested fixes

Every issue gets a "💡 How to fix" note (`lib/suggestFixes.js`): a
framework-agnostic template per check type, plus a scoping note from the
scan data:

- **Broken at every viewport** → safe to fix unconditionally.
- **Broken at only some viewports** → scope the fix (e.g. a `max-width`
  media query or breakpoint variant) to the broken range, so sizes that
  already pass keep passing.
- **`horizontal-overflow`** can name a different element per viewport, so
  it's grouped per page instead of per element - the note is about
  whether the page scrolls horizontally at that size, not one element.

This is rule-based text grounded in what was measured - not code
generation or an LLM. See "What this doesn't do" for why rewriting your
source is a different, harder problem.

## Setup

### Prerequisites

- Node.js 18+ and npm

### Install

```bash
git clone <this-repo-url>
cd viewport-doctor-web
npm install
```

`npm install` also downloads Playwright's bundled Chromium the first time
(a one-off ~150MB download) - no environment variables, API keys, or
other setup required (see `.env.example`).

### Run it

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Click **Load demo
example** to instantly fill in the form with the bundled demo page, then
**Run scan** - no separate app needs to be running first, since the demo
(`app/demo/page.tsx`) is a real React route that ships inside this same
project.

### Scan your own app

Start your app's dev server, then in the form:

- **Base URL** - e.g. `http://localhost:3000`
- **Pages** (one per line) - e.g. `/`, `/about`, `/dashboard`
- **Viewports** - the four presets are pre-selected; uncheck any you don't need, remove one with the `×`, or add a custom width/height

Click **Run scan**. Results appear grouped per page, with a pill per
viewport (✅ clean, ❌ N issues, or ⚠️ if the page failed to load at that
size) - click a pill to see that viewport's highlighted screenshot and
issue list.

The same functionality is also available directly as an API:

```bash
curl -s -X POST http://localhost:3000/api/scan \
  -H "Content-Type: application/json" \
  -d '{
    "baseUrl": "http://localhost:3000",
    "pages": ["/", "/about"],
    "viewports": [
      { "label": "Mobile", "width": 390, "height": 844 },
      { "label": "Desktop", "width": 1440, "height": 900 }
    ]
  }'
```

`urls` (an array of full URLs) can be sent instead of `baseUrl` + `pages`
if you'd rather not have the server resolve relative paths itself.

### API request body

| Field | Required | Description |
|---|---|---|
| `baseUrl` | with `pages` | Base URL every page path is resolved against |
| `pages` | with `baseUrl` | Array of page paths, e.g. `["/", "/about"]` |
| `urls` | instead of `baseUrl`+`pages` | Array of full URLs to scan directly |
| `viewports` | yes | Array of `{ label?, width, height }` - at least one; width/height are clamped to 200-3000px server-side |
| `timeoutMs` | no | Navigation timeout per page (default `15000`) |
| `settleMs` | no | Extra wait after page load before measuring (default `500`) |

Response shape: `{ pages: [{ url, viewports: [...], fixSuggestions: [...] }] }`.

- Each viewport entry: `{ label, width, height, issues, screenshot, navigationError? }`. Each issue is `{ check, message, selector, rect: {x, y, width, height} }`. `screenshot` is a `data:image/png;base64,...` string (a full-page screenshot with every flagged element highlighted).
- Each `fixSuggestions` entry (one per distinct bug found anywhere on the page - see "Suggested fixes" above): `{ check, selector, message, elementVaries, brokenViewports, okViewports, scoped, breakpointHint, suggestion, fixCode }`. `suggestion` is the ready-to-read advice text; `fixCode` is a copy-pasteable CSS snippet for the same fix, already wrapped in the matching `@media (max-width: ...)` when the bug is scoped to specific viewports, so pasting it in as-is won't disturb sizes that already pass; `brokenViewports`/`okViewports` are `{label, width, height}` arrays; `elementVaries` is `true` only for `horizontal-overflow` (selector is `null` in that case, since the offending element can differ by viewport).

## Usage example

Real output from `POST /api/scan` against this project's own bundled demo
page, scanned at all four default viewports - not a mockup:

| Viewport | Issues | What's firing |
|---|---|---|
| Mobile (390×844) | 6 | All six: `horizontal-overflow` (card row + dialog both poke out), `clipped-element`, `overlapping-elements`, `text-overflow`, `oversized-modal` (900px dialog > 390px viewport), `overflowing-image`. |
| Tablet (768×1024) | 7 | Same six checks, but `horizontal-overflow` now fires twice - the card row and the 900px dialog each independently stick out past the container once it's no longer wide enough to hold both centered. |
| Laptop (1024×768) | 6 | `horizontal-overflow` still fires (twice, same reason as Tablet) - the card row and dialog still don't fit within the page's own centered content column at this width. `oversized-modal` disappears (900px now fits under 1024px), but the dialog still contributes to the overflow finding above. |
| Desktop (1440×900) | 4 | Only `clipped-element`, `overlapping-elements`, `text-overflow`, `overflowing-image` remain - at this width there's enough margin for both the card row and the dialog to sit fully inside the viewport, so `horizontal-overflow` and `oversized-modal` both disappear. |

That progression is the tool's actual point: `horizontal-overflow` and
`oversized-modal` are two genuinely different, viewport-conditional bugs
that don't fully disappear until a wide-enough screen - a developer
checking only their own (usually wide) monitor would never see either
one, and even "Laptop"-sized screens aren't automatically safe.

## Known limitations

- Checks static, already-rendered DOM state only - it doesn't click
  buttons, open menus, or interact with the page to discover bugs that
  only appear after a user action.
- `overlapping-elements` only compares `button`/`a[href]`/`input`/`[role="button"]` elements against each other, not arbitrary text/decorative elements, to keep false positives low. A real overlap involving a plain `<div>` or `<span>` won't be flagged.
- `horizontal-overflow` reports the outermost element whose own parent doesn't overflow, not necessarily the single deepest cause - a screenshot with the highlight box is included specifically so you can visually confirm which part is actually too wide. Because that reported element can change between viewports, its fix suggestions are grouped per page instead of per element (see "Suggested fixes").
- Suggested fixes are generic, rule-based text per check type, not an analysis of your actual code - they're a starting point ("here's the class of fix that usually applies"), not a guaranteed-correct patch for your specific markup/CSS.
- Each scan launches a fresh headless browser per viewport and captures a full-page screenshot; the API route has a 60-second execution budget (`maxDuration`), which is enough for a handful of page × viewport combinations but not a large matrix.
- Screenshots are returned as base64 inside the JSON response for simplicity - fine for interactive use, but a large page × viewport matrix will produce a sizeable response payload.

## What this doesn't do (and why)

This tool detects issues and writes out how to fix them in plain
language - it does not modify your source code. The suggestion text is
generic, rule-based guidance keyed off the check type (e.g. "add
`max-width: 100%`") plus what was measured across viewports; it doesn't
know your actual CSS, your build tooling, or which file rendered the
element, so it can't produce a diff, let alone apply one.

Reliably closing that loop - going from "here's what's wrong and roughly
how to fix it" to "here's an actual patch to your source" - needs a
fundamentally different set of pieces: mapping a flagged DOM element back
to the exact source file/line that rendered it (typically via a
build-time plugin that tags elements with their origin), an LLM that can
read that source and reason about *why* the layout breaks in this
specific codebase (not just a generic template), and a review/approval
step before any fix is applied - since a CSS change that fixes one
viewport can just as easily break another one that wasn't being checked
(the scoping notes in "Suggested fixes" above exist specifically to flag
that risk in the meantime). That's a meaningfully larger, separate
project layered on top of this one, not an extension of the detection
engine itself.

## Tech stack

- [Next.js](https://nextjs.org) (App Router) + [React](https://react.dev) + TypeScript - the web app and dashboard UI
- [Tailwind CSS](https://tailwindcss.com) - styling
- [Playwright](https://playwright.dev) - real headless Chromium automation, viewport emulation, DOM measurement via `page.evaluate()`, and screenshot capture, run server-side in a Node.js API route (`export const runtime = "nodejs"`, since Playwright needs a real Node process rather than the Edge runtime)
- [Vitest](https://vitest.dev) - test runner
- `lib/nextServer.js` spawns a real `next start` production server for tests to scan against (see "Testing" below)

## Testing

```bash
npm test
```

`npm test` runs a `pretest` step (`next build`) first, then 22 tests:
`test/scanViewport.test.js` and `test/route.test.ts` run against a real
headless browser and a real `next start` production server (no mocking
of the DOM, Playwright, or the Next.js route handler) - scanning the
bundled `/demo` page directly through the scanning engine at both Mobile
and Desktop viewports and asserting on exactly which checks fire at each
size (matching the "Usage example" above), plus error handling for an
unreachable page, missing URLs/viewports, invalid request bodies, and
server-side viewport clamping, plus that the API response includes a
correctly-scoped fix suggestion per issue. `test/suggestFixes.test.js` is
a fast, pure-function suite (no browser or server needed) that exercises
the scoping logic directly - unconditional vs. scoped bugs, the
breakpoint hint, the `horizontal-overflow` cross-viewport grouping, and
edge cases like a page with no issues at all.

## Adopting this in another project

Copy `lib/` (which includes `suggestFixes.js`) and `app/api/scan/`, add
the dependencies listed in `package.json`, then reuse (or restyle)
`app/page.tsx` as a starting point for your own dashboard, or call
`POST /api/scan` from any frontend you already have.
