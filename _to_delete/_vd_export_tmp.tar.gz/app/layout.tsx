import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Viewport Doctor",
  description:
    "Check your app's pages at several screen sizes with a real headless browser and catch responsive layout bugs - horizontal overflow, clipped elements, overlaps, and more.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
