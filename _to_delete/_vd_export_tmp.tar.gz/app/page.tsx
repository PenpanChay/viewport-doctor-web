"use client";

import { useId, useState } from "react";

type ViewportEntry = {
  id: string;
  label: string;
  width: number;
  height: number;
  enabled: boolean;
};

type ScanIssue = {
  check: string;
  message: string;
  selector: string;
  rect: { x: number; y: number; width: number; height: number };
};

type ScanViewportResult = {
  label: string;
  width: number;
  height: number;
  issues: ScanIssue[];
  screenshot: string;
  navigationError?: string;
};

type FixSuggestion = {
  check: string;
  selector: string | null;
  message: string;
  elementVaries: boolean;
  brokenViewports: { label: string; width: number; height: number }[];
  okViewports: { label: string; width: number; height: number }[];
  scoped: boolean;
  breakpointHint: string | null;
  suggestion: string;
  fixCode: string;
};

type ScanPage = {
  url: string;
  viewports: ScanViewportResult[];
  fixSuggestions: FixSuggestion[];
};

type ScanResponse = { pages: ScanPage[] } | { error: string };

const DEFAULT_VIEWPORTS: ViewportEntry[] = [
  { id: "mobile", label: "Mobile", width: 390, height: 844, enabled: true },
  { id: "tablet", label: "Tablet", width: 768, height: 1024, enabled: true },
  { id: "laptop", label: "Laptop", width: 1024, height: 768, enabled: true },
  { id: "desktop", label: "Desktop", width: 1440, height: 900, enabled: true },
];

// Human-readable label + icon + color per check type, so an issue reads at
// a glance as "horizontal overflow" vs. "overlapping elements" rather than
// a raw identifier. Keyed by the exact strings lib/checks.js produces.
const CHECK_META: Record<string, { label: string; icon: string; className: string }> = {
  "horizontal-overflow": {
    label: "Horizontal overflow",
    icon: "↔️",
    className: "bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300",
  },
  "clipped-element": {
    label: "Clipped element",
    icon: "✂️",
    className: "bg-orange-50 text-orange-700 dark:bg-orange-950/60 dark:text-orange-300",
  },
  "overlapping-elements": {
    label: "Overlapping elements",
    icon: "🔀",
    className: "bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300",
  },
  "text-overflow": {
    label: "Text overflow",
    icon: "✏️",
    className: "bg-fuchsia-50 text-fuchsia-700 dark:bg-fuchsia-950/60 dark:text-fuchsia-300",
  },
  "oversized-modal": {
    label: "Oversized modal",
    icon: "🗔️",
    className: "bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300",
  },
  "overflowing-image": {
    label: "Overflowing image",
    icon: "🖼️",
    className: "bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300",
  },
};

function checkMeta(check: string) {
  return (
    CHECK_META[check] ?? {
      label: check,
      icon: "•",
      className: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300",
    }
  );
}

function parseLines(value: string): string[] {
  return value
    .split(/[\n,]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export default function Home() {
  const [baseUrl, setBaseUrl] = useState("");
  const [pagesInput, setPagesInput] = useState("");
  const [viewports, setViewports] = useState<ViewportEntry[]>(DEFAULT_VIEWPORTS);
  const [customWidth, setCustomWidth] = useState("");
  const [customHeight, setCustomHeight] = useState("");
  const [customLabel, setCustomLabel] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ScanPage[] | null>(null);
  const [activeViewport, setActiveViewport] = useState<Record<string, string>>({});
  const customFormId = useId();

  function loadDemoExample() {
    setBaseUrl(window.location.origin);
    setPagesInput("/demo");
    setResult(null);
    setError(null);
  }

  function toggleViewport(id: string) {
    setViewports((prev) => prev.map((v) => (v.id === id ? { ...v, enabled: !v.enabled } : v)));
  }

  function removeViewport(id: string) {
    setViewports((prev) => prev.filter((v) => v.id !== id));
  }

  function addCustomViewport() {
    const width = Number(customWidth);
    const height = Number(customHeight);
    if (!width || !height || width <= 0 || height <= 0) return;
    const id = `custom-${Date.now()}`;
    setViewports((prev) => [
      ...prev,
      { id, label: customLabel.trim() || `${width}×${height}`, width, height, enabled: true },
    ]);
    setCustomWidth("");
    setCustomHeight("");
    setCustomLabel("");
  }

  async function runScan() {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const pages = parseLines(pagesInput);
      if (!baseUrl.trim() || pages.length === 0) {
        throw new Error("Enter a base URL and at least one page path.");
      }
      const activeViewports = viewports.filter((v) => v.enabled);
      if (activeViewports.length === 0) {
        throw new Error("Select at least one viewport to check.");
      }

      const res = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          baseUrl: baseUrl.trim(),
          pages,
          viewports: activeViewports.map((v) => ({ label: v.label, width: v.width, height: v.height })),
        }),
      });

      const data: ScanResponse = await res.json();
      if (!res.ok || "error" in data) {
        throw new Error("error" in data ? data.error : `Request failed with status ${res.status}`);
      }
      setResult(data.pages);
      // Default each page's selected tab to its first failing viewport, so
      // opening the results immediately shows a problem instead of a
      // clean pass that happens to sort first.
      const defaults: Record<string, string> = {};
      for (const page of data.pages) {
        const firstFailing = page.viewports.find((v) => v.issues.length > 0 || v.navigationError);
        defaults[page.url] = (firstFailing ?? page.viewports[0])?.label ?? "";
      }
      setActiveViewport(defaults);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-50 to-white dark:from-black dark:to-zinc-950">
      <div className="mx-auto max-w-4xl px-6 py-16">
        <header className="mb-10 rounded-2xl bg-gradient-to-r from-sky-500 to-emerald-500 p-8 text-white shadow-lg shadow-sky-500/20">
          <h1 className="text-2xl font-semibold">Viewport Doctor</h1>
          <p className="mt-1 text-sm text-white/85">
            Opens your app&apos;s pages at several screen sizes in a real headless browser and flags responsive
            layout bugs - horizontal overflow, clipped elements, overlaps, text overflow, oversized modals, and
            overflowing images - with a highlighted screenshot and a suggested fix for each one it finds, scoped so
            it won&apos;t disturb the viewport sizes that already look fine.
          </p>
        </header>

        <section className="mb-10 rounded-xl border border-black/[.08] bg-white p-6 shadow-sm dark:border-white/[.1] dark:bg-zinc-900">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Run a scan</h2>
            <button
              type="button"
              onClick={loadDemoExample}
              className="rounded-full border border-black/[.1] px-3 py-1 text-xs font-medium text-zinc-600 transition hover:bg-black/[.04] dark:border-white/[.15] dark:text-zinc-300 dark:hover:bg-white/[.06]"
            >
              Load demo example
            </button>
          </div>

          <div className="flex flex-col gap-4">
            <label className="flex flex-col gap-1 text-sm">
              <span className="font-medium">Base URL</span>
              <input
                type="text"
                value={baseUrl}
                onChange={(e) => setBaseUrl(e.target.value)}
                placeholder="http://localhost:3000"
                className="rounded-lg border border-black/[.1] bg-transparent px-3 py-2 text-sm outline-none focus:border-sky-500 dark:border-white/[.15]"
              />
            </label>

            <label className="flex flex-col gap-1 text-sm">
              <span className="font-medium">Pages (one per line)</span>
              <textarea
                value={pagesInput}
                onChange={(e) => setPagesInput(e.target.value)}
                placeholder={"/\n/about\n/dashboard"}
                rows={3}
                className="rounded-lg border border-black/[.1] bg-transparent px-3 py-2 font-mono text-sm outline-none focus:border-sky-500 dark:border-white/[.15]"
              />
            </label>

            <div className="flex flex-col gap-2 text-sm">
              <span className="font-medium">Viewports to check</span>
              <div className="flex flex-wrap gap-2">
                {viewports.map((v) => (
                  <span
                    key={v.id}
                    className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs transition ${
                      v.enabled
                        ? "border-sky-300 bg-sky-50 text-sky-800 dark:border-sky-800 dark:bg-sky-950/60 dark:text-sky-200"
                        : "border-black/[.1] text-zinc-400 dark:border-white/[.15]"
                    }`}
                  >
                    <label className="flex cursor-pointer items-center gap-1.5">
                      <input type="checkbox" checked={v.enabled} onChange={() => toggleViewport(v.id)} />
                      {v.label} ({v.width}×{v.height})
                    </label>
                    <button
                      type="button"
                      onClick={() => removeViewport(v.id)}
                      aria-label={`Remove ${v.label} viewport`}
                      className="text-zinc-400 hover:text-rose-500"
                    >
                      &times;
                    </button>
                  </span>
                ))}
              </div>

              <div className="mt-1 flex flex-wrap items-center gap-2">
                <label htmlFor={`${customFormId}-width`} className="sr-only">
                  Custom width
                </label>
                <input
                  id={`${customFormId}-width`}
                  type="number"
                  value={customWidth}
                  onChange={(e) => setCustomWidth(e.target.value)}
                  placeholder="width"
                  className="w-24 rounded-lg border border-black/[.1] bg-transparent px-2 py-1.5 text-sm outline-none focus:border-sky-500 dark:border-white/[.15]"
                />
                <span className="text-zinc-400">×</span>
                <input
                  type="number"
                  value={customHeight}
                  onChange={(e) => setCustomHeight(e.target.value)}
                  placeholder="height"
                  className="w-24 rounded-lg border border-black/[.1] bg-transparent px-2 py-1.5 text-sm outline-none focus:border-sky-500 dark:border-white/[.15]"
                />
                <input
                  type="text"
                  value={customLabel}
                  onChange={(e) => setCustomLabel(e.target.value)}
                  placeholder="label (optional)"
                  className="w-36 rounded-lg border border-black/[.1] bg-transparent px-2 py-1.5 text-sm outline-none focus:border-sky-500 dark:border-white/[.15]"
                />
                <button
                  type="button"
                  onClick={addCustomViewport}
                  className="rounded-full border border-black/[.1] px-3 py-1.5 text-xs font-medium text-zinc-600 transition hover:bg-black/[.04] dark:border-white/[.15] dark:text-zinc-300 dark:hover:bg-white/[.06]"
                >
                  + Add custom viewport
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={runScan}
              disabled={loading}
              className="self-start rounded-full bg-sky-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-sky-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Scanning…" : "Run scan"}
            </button>
          </div>
        </section>

        {error && (
          <div className="mb-6 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800 dark:border-rose-900 dark:bg-rose-950 dark:text-rose-300">
            {error}
          </div>
        )}

        {result && (
          <section className="mb-6">
            <h2 className="mb-4 text-lg font-semibold">Results</h2>
            <div className="flex flex-col gap-6">
              {result.map((page) => {
                const active = activeViewport[page.url] ?? page.viewports[0]?.label;
                const activeResult = page.viewports.find((v) => v.label === active) ?? page.viewports[0];
                return (
                  <div
                    key={page.url}
                    className="rounded-xl border border-black/[.08] bg-white p-4 shadow-sm dark:border-white/[.1] dark:bg-zinc-900"
                  >
                    <div className="mb-3 break-all font-mono text-sm font-medium">{page.url}</div>

                    <div className="mb-3 flex flex-wrap gap-2">
                      {page.viewports.map((v) => {
                        const isActive = v.label === active;
                        const hasIssues = v.issues.length > 0 || v.navigationError;
                        return (
                          <button
                            key={v.label}
                            type="button"
                            onClick={() => setActiveViewport((prev) => ({ ...prev, [page.url]: v.label }))}
                            className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                              isActive
                                ? "border-sky-500 bg-sky-600 text-white"
                                : hasIssues
                                  ? "border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900 dark:bg-rose-950/60 dark:text-rose-300"
                                  : "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/60 dark:text-emerald-300"
                            }`}
                          >
                            {v.label} ({v.width}×{v.height}) {v.navigationError ? "⚠️" : hasIssues ? `❌ ${v.issues.length}` : "✅"}
                          </button>
                        );
                      })}
                    </div>

                    {activeResult && (
                      <div className="flex flex-col gap-3">
                        {activeResult.navigationError ? (
                          <p className="text-sm text-rose-600 dark:text-rose-400">
                            Could not load this page at {activeResult.width}×{activeResult.height}:{" "}
                            {activeResult.navigationError}
                          </p>
                        ) : activeResult.issues.length === 0 ? (
                          <p className="text-sm text-emerald-600 dark:text-emerald-400">
                            Clean at {activeResult.width}×{activeResult.height} - nothing to report.
                          </p>
                        ) : (
                          <ul className="flex flex-col gap-2">
                            {activeResult.issues.map((issue, i) => {
                              const meta = checkMeta(issue.check);
                              // Page-level checks (currently just horizontal-overflow)
                              // can legitimately name a different element at each
                              // viewport, so they're matched by check alone - see
                              // lib/suggestFixes.js's PAGE_LEVEL_CHECKS.
                              const fix = page.fixSuggestions?.find(
                                (f) => f.check === issue.check && (f.elementVaries || f.selector === issue.selector)
                              );
                              return (
                                <li
                                  key={i}
                                  className="flex flex-col gap-1 rounded-lg border border-black/[.06] px-3 py-2 text-sm dark:border-white/[.08]"
                                >
                                  <div className="flex flex-wrap items-start gap-2">
                                    <span
                                      className={`inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium ${meta.className}`}
                                    >
                                      <span aria-hidden>{meta.icon}</span>
                                      {meta.label}
                                    </span>
                                    <span className="break-all">{issue.message}</span>
                                  </div>
                                  <span className="pl-1 font-mono text-xs text-zinc-500 dark:text-zinc-400">
                                    {issue.selector}
                                  </span>
                                  {fix && (
                                    <div className="mt-1 rounded-md bg-emerald-50 px-3 py-2 text-xs leading-relaxed text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200">
                                      <span className="font-semibold">💡 How to fix: </span>
                                      {fix.suggestion}
                                      {fix.fixCode && (
                                        // Already scoped (e.g. wrapped in the matching
                                        // @media query) by lib/suggestFixes.js so pasting
                                        // this in as-is won't disturb viewports that are
                                        // already passing - see the prose above it for why.
                                        <pre className="mt-2 overflow-x-auto rounded bg-emerald-900/90 px-3 py-2 font-mono text-[11px] leading-relaxed text-emerald-50 dark:bg-black/60">
                                          <code>{fix.fixCode}</code>
                                        </pre>
                                      )}
                                    </div>
                                  )}
                                </li>
                              );
                            })}
                          </ul>
                        )}

                        {activeResult.screenshot && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={activeResult.screenshot}
                            alt={`Screenshot of ${page.url} at ${activeResult.width}x${activeResult.height}, flagged issues highlighted`}
                            className="w-full rounded-lg border border-black/[.08] dark:border-white/[.1]"
                          />
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        <footer className="mt-12 rounded-xl border border-dashed border-black/[.1] p-4 text-sm text-zinc-500 dark:border-white/[.15]">
          Click <strong>Load demo example</strong> then <strong>Run scan</strong> to see it catch a horizontal
          overflow, a clipped button, overlapping elements, text overflow, an oversized modal, and an overflowing
          image from the bundled <code className="rounded bg-black/[.06] px-1 py-0.5 dark:bg-white/[.08]">/demo</code>{" "}
          page - a real React route in this same app, no separate app needs to be running first.
        </footer>
      </div>
    </div>
  );
}
