/**
 * Bundled demo target for viewport-doctor-web itself - a real React page
 * (Server Component, no interactivity needed) containing one deliberate
 * bug per check the tool runs, so a scan against it has real (if
 * intentionally injected) issues to find at various screen sizes rather
 * than mocked data. See README's "Try it on the bundled demo" section.
 *
 * A few of these are viewport-conditional on purpose - e.g. the card row
 * only overflows at narrower widths - to demonstrate the tool's actual
 * value: catching a bug that only shows up on some screen sizes, not
 * every one. Concretely: at Mobile/Tablet/Laptop the fixed-width card row
 * (974px total) is wider than the viewport itself, so `horizontal-overflow`
 * fires; only at Desktop (1440px) is there enough room for it. See the
 * README's "Usage example" for the exact numbers at each size.
 */
export default function DemoPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16 font-sans text-zinc-900 dark:text-zinc-50">
      <h1 className="text-xl font-semibold">Viewport Doctor - Demo</h1>
      <p className="mt-3 text-sm text-zinc-600 dark:text-zinc-400">
        This page intentionally has one responsive-layout bug per category the scanner checks for. Scan it at
        Mobile/Tablet vs. Laptop/Desktop and compare - some of these only show up at narrow widths.
      </p>

      {/* 1. Horizontal overflow: three fixed-width cards that don't wrap,
          overflowing the viewport at Mobile/Tablet/Laptop widths (974px of
          cards doesn't fit) but fitting once the viewport reaches Desktop
          width (1440px). */}
      <section className="mt-10">
        <h2 className="text-sm font-semibold text-zinc-500">1. Horizontal overflow</h2>
        <div className="mt-2 flex gap-3 overflow-visible whitespace-nowrap">
          <div className="inline-block w-[320px] shrink-0 rounded-lg border border-zinc-300 p-4 dark:border-zinc-700">
            Card one - fixed 320px wide, does not wrap
          </div>
          <div className="inline-block w-[320px] shrink-0 rounded-lg border border-zinc-300 p-4 dark:border-zinc-700">
            Card two - fixed 320px wide, does not wrap
          </div>
          <div className="inline-block w-[320px] shrink-0 rounded-lg border border-zinc-300 p-4 dark:border-zinc-700">
            Card three - fixed 320px wide, does not wrap
          </div>
        </div>
      </section>

      {/* 2. Clipped/cut-off button: a fixed-width, overflow-hidden toolbar
          holding more buttons than it can show. */}
      <section className="mt-10">
        <h2 className="text-sm font-semibold text-zinc-500">2. Clipped button</h2>
        <div className="mt-2 flex w-[340px] gap-3 overflow-hidden rounded-lg border border-zinc-300 p-2 dark:border-zinc-700">
          <button type="button" className="w-[110px] shrink-0 rounded bg-indigo-600 px-3 py-2 text-sm text-white">
            Save
          </button>
          <button type="button" className="w-[110px] shrink-0 rounded bg-zinc-600 px-3 py-2 text-sm text-white">
            Cancel
          </button>
          <button type="button" className="w-[110px] shrink-0 rounded bg-emerald-600 px-3 py-2 text-sm text-white">
            Publish
          </button>
        </div>
      </section>

      {/* 3. Overlapping elements: a "NEW" badge anchor positioned directly
          over a sibling button - two independent interactive elements
          whose boxes genuinely overlap, not a parent/child relationship
          (which wouldn't count as a bug). */}
      <section className="mt-10">
        <h2 className="text-sm font-semibold text-zinc-500">3. Overlapping elements</h2>
        <div className="relative mt-2 inline-block">
          <button type="button" className="rounded-lg bg-zinc-800 px-4 py-3 text-white">
            Upgrade your plan
          </button>
          <a
            href="#"
            className="absolute -right-3 -top-3 rounded-full bg-pink-600 px-2 py-1 text-xs font-bold text-white"
          >
            NEW
          </a>
        </div>
      </section>

      {/* 4. Text overflow/truncation: a fixed-width label with long text,
          no wrap/ellipsis handling. */}
      <section className="mt-10">
        <h2 className="text-sm font-semibold text-zinc-500">4. Text overflow</h2>
        <p className="mt-2 w-[160px] overflow-hidden whitespace-nowrap rounded-lg border border-zinc-300 p-2 text-sm dark:border-zinc-700">
          This label text is much longer than its fixed-width box
        </p>
      </section>

      {/* 5. Oversized modal: a dialog-like element with a fixed px width
          (900px) wider than the Mobile/Tablet viewports themselves (so the
          oversized-modal check fires there), but narrower than Laptop/
          Desktop viewports (so oversized-modal doesn't fire there - though
          at Laptop width it can still contribute to a separate
          horizontal-overflow finding, since it isn't centered within the
          page's own narrower content column). */}
      <section className="mt-10">
        <h2 className="text-sm font-semibold text-zinc-500">5. Oversized modal</h2>
        <div
          role="dialog"
          aria-label="Example oversized dialog"
          className="mt-2 w-[900px] max-w-none rounded-lg border-2 border-dashed border-amber-500 p-6"
        >
          A dialog fixed at 900px wide - fine on a laptop/desktop screen, but wider than a phone or tablet viewport.
        </div>
      </section>

      {/* 6. Overflowing image: an image with a fixed px width wider than
          its container, no max-width: 100%. */}
      <section className="mt-10">
        <h2 className="text-sm font-semibold text-zinc-500">6. Overflowing image</h2>
        <div className="mt-2 max-w-sm rounded-lg border border-zinc-300 p-2 dark:border-zinc-700">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/demo-banner.svg"
            alt="Demo banner wider than its container"
            width={500}
            height={120}
            style={{ width: '500px', maxWidth: 'none', height: 'auto' }}
          />
        </div>
      </section>
    </main>
  );
}
