import path from "path";
import { fileURLToPath } from "url";
import { NextRequest } from "next/server";
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { startNextServer } from "../lib/nextServer.js";
import { POST } from "../app/api/scan/route";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.join(__dirname, "..");

function postRequest(body: unknown) {
  return new NextRequest("http://localhost/api/scan", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("POST /api/scan (route handler, real browser + real Next.js server)", () => {
  let nextServer: Awaited<ReturnType<typeof startNextServer>>;
  let baseUrl: string;

  beforeAll(async () => {
    nextServer = await startNextServer(PROJECT_ROOT);
    baseUrl = `http://localhost:${nextServer.port}`;
  }, 30000);

  afterAll(async () => {
    await nextServer.close();
  });

  it("scans the demo page at the requested viewports and returns flattened per-viewport results", async () => {
    const response = await POST(
      postRequest({
        baseUrl,
        pages: ["/demo"],
        viewports: [
          { label: "Mobile", width: 390, height: 844 },
          { label: "Desktop", width: 1440, height: 900 },
        ],
      })
    );
    expect(response.status).toBe(200);

    const data = await response.json();
    expect(data.pages).toHaveLength(1);
    expect(data.pages[0].viewports).toHaveLength(2);

    const mobile = data.pages[0].viewports.find((v: { label: string }) => v.label === "Mobile");
    expect(mobile.width).toBe(390);
    expect(mobile.height).toBe(844);
    expect(mobile.issues.length).toBeGreaterThan(0);
    expect(mobile.screenshot).toMatch(/^data:image\/png;base64,/);
  }, 30000);

  it("includes a fix suggestion per distinct issue, scoped when the bug doesn't affect every viewport", async () => {
    const response = await POST(
      postRequest({
        baseUrl,
        pages: ["/demo"],
        viewports: [
          { label: "Mobile", width: 390, height: 844 },
          { label: "Desktop", width: 1440, height: 900 },
        ],
      })
    );
    expect(response.status).toBe(200);
    const data = await response.json();
    const fixSuggestions = data.pages[0].fixSuggestions;
    expect(Array.isArray(fixSuggestions)).toBe(true);
    expect(fixSuggestions.length).toBeGreaterThan(0);

    // clipped-element fires at both viewports on the demo page -> unconditional.
    const clipped = fixSuggestions.find((f: { check: string }) => f.check === "clipped-element");
    expect(clipped.scoped).toBe(false);
    expect(clipped.suggestion).toMatch(/occurs at every viewport/i);

    // horizontal-overflow fires at Mobile but not Desktop on the demo page -> scoped.
    const overflow = fixSuggestions.find((f: { check: string }) => f.check === "horizontal-overflow");
    expect(overflow.scoped).toBe(true);
    expect(overflow.okViewports.some((v: { label: string }) => v.label === "Desktop")).toBe(true);
    expect(overflow.suggestion).toMatch(/don't disturb/i);
  }, 30000);

  it("rejects a request with neither urls nor baseUrl+pages", async () => {
    const response = await POST(postRequest({ viewports: [{ label: "Mobile", width: 390, height: 844 }] }));
    expect(response.status).toBe(400);
    const data = await response.json();
    expect(data.error).toMatch(/urls|baseUrl/);
  });

  it("rejects a request with no viewports", async () => {
    const response = await POST(postRequest({ baseUrl, pages: ["/demo"], viewports: [] }));
    expect(response.status).toBe(400);
    const data = await response.json();
    expect(data.error).toMatch(/viewport/i);
  });

  it("rejects a request body that isn't valid JSON", async () => {
    const request = new NextRequest("http://localhost/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "not json",
    });
    const response = await POST(request);
    expect(response.status).toBe(400);
    const data = await response.json();
    expect(data.error).toMatch(/valid JSON/);
  });

  it("clamps an out-of-range custom viewport instead of passing it straight to the browser", async () => {
    const response = await POST(
      postRequest({
        baseUrl,
        pages: ["/demo"],
        viewports: [{ label: "Huge", width: 50000, height: 50000 }],
      })
    );
    expect(response.status).toBe(200);
    const data = await response.json();
    const huge = data.pages[0].viewports[0];
    expect(huge.width).toBeLessThanOrEqual(3000);
    expect(huge.height).toBeLessThanOrEqual(3000);
  }, 20000);
});
