import { describe, it, expect } from 'vitest';
import { buildFixSuggestions } from '../lib/suggestFixes.js';

const MOBILE = { label: 'Mobile', width: 390, height: 844 };
const DESKTOP = { label: 'Desktop', width: 1440, height: 900 };

function issueFixture(check, message = `${check} message`, selector = `div.${check}`) {
  return { check, message, selector };
}

describe('buildFixSuggestions (pure, no browser/server needed)', () => {
  it('marks a bug present at every scanned viewport as unconditional (safe to fix globally)', () => {
    const pageResult = {
      viewports: [
        { ...MOBILE, issues: [issueFixture('clipped-element')] },
        { ...DESKTOP, issues: [issueFixture('clipped-element')] },
      ],
    };
    const [suggestion] = buildFixSuggestions(pageResult);
    expect(suggestion.check).toBe('clipped-element');
    expect(suggestion.elementVaries).toBe(false);
    expect(suggestion.selector).toBe('div.clipped-element');
    expect(suggestion.scoped).toBe(false);
    expect(suggestion.okViewports).toEqual([]);
    expect(suggestion.suggestion).toMatch(/occurs at every viewport/i);
    expect(suggestion.suggestion).toMatch(/Mobile \(390px\)/);
    expect(suggestion.suggestion).toMatch(/Desktop \(1440px\)/);
  });

  it('marks a bug present only at some viewports as scoped, with a breakpoint hint when the split is clean', () => {
    const pageResult = {
      viewports: [
        { ...MOBILE, issues: [issueFixture('horizontal-overflow')] },
        { ...DESKTOP, issues: [] },
      ],
    };
    const [suggestion] = buildFixSuggestions(pageResult);
    expect(suggestion.scoped).toBe(true);
    expect(suggestion.brokenViewports).toEqual([MOBILE]);
    expect(suggestion.okViewports).toEqual([DESKTOP]);
    expect(suggestion.breakpointHint).toMatch(/390px/);
    expect(suggestion.suggestion).toMatch(/only breaks/i);
    expect(suggestion.suggestion).toMatch(/already fine at Desktop \(1440px\)/);
    // The core ask: don't disturb the viewport that's already OK.
    expect(suggestion.suggestion).toMatch(/don't disturb/i);
  });

  it('merges horizontal-overflow findings into one page-level group even when the reported element differs by viewport', () => {
    // Mimics the real demo page: at a very narrow width the checker names
    // the whole <main>, but at a mid width it names two different, more
    // specific elements instead - same underlying page-level bug, three
    // different selectors.
    const TABLET = { label: 'Tablet', width: 768, height: 1024 };
    const pageResult = {
      viewports: [
        { ...MOBILE, issues: [issueFixture('horizontal-overflow', 'main overflow', 'main.container')] },
        {
          ...TABLET,
          issues: [
            issueFixture('horizontal-overflow', 'card overflow', 'div.card-three'),
            issueFixture('horizontal-overflow', 'dialog overflow', 'div.dialog'),
          ],
        },
        { ...DESKTOP, issues: [] },
      ],
    };
    const suggestions = buildFixSuggestions(pageResult);
    const horizontalOverflow = suggestions.filter((s) => s.check === 'horizontal-overflow');
    expect(horizontalOverflow).toHaveLength(1); // not 2 or 3, despite 3 distinct selectors

    const [suggestion] = horizontalOverflow;
    expect(suggestion.elementVaries).toBe(true);
    expect(suggestion.selector).toBeNull();
    // Tablet must count as broken exactly once, not twice, even though two
    // distinct elements were both flagged there.
    expect(suggestion.brokenViewports).toHaveLength(2);
    expect(suggestion.brokenViewports.map((v) => v.label).sort()).toEqual(['Mobile', 'Tablet']);
    expect(suggestion.okViewports).toEqual([DESKTOP]);
    expect(suggestion.scoped).toBe(true);
    // Wording must not claim the page-wide problem is "fixed" at Tablet just
    // because a different element was blamed there than at Mobile.
    expect(suggestion.suggestion).toMatch(/differ by viewport/i);
  });

  it('omits the breakpoint hint (but still flags scoped) when broken/OK widths interleave', () => {
    const TABLET = { label: 'Tablet', width: 768, height: 1024 };
    // Broken at 390 and 1440, OK at 768 - not a clean narrow-vs-wide split.
    const pageResult = {
      viewports: [
        { ...MOBILE, issues: [issueFixture('overlapping-elements')] },
        { ...TABLET, issues: [] },
        { ...DESKTOP, issues: [issueFixture('overlapping-elements')] },
      ],
    };
    const [suggestion] = buildFixSuggestions(pageResult);
    expect(suggestion.scoped).toBe(true);
    expect(suggestion.breakpointHint).toBeNull();
    expect(suggestion.suggestion).toMatch(/isn't a simple/i);
    expect(suggestion.suggestion).toMatch(/re-scan every viewport/i);
  });

  it('skips viewports that failed to navigate entirely', () => {
    const pageResult = {
      viewports: [
        { ...MOBILE, issues: [issueFixture('text-overflow')] },
        { ...DESKTOP, issues: [], navigationError: 'timeout' },
      ],
    };
    const suggestions = buildFixSuggestions(pageResult);
    expect(suggestions).toHaveLength(1);
    // Desktop never successfully loaded, so it must not be counted as "OK".
    expect(suggestions[0].okViewports).toEqual([]);
    expect(suggestions[0].scoped).toBe(false);
  });

  it('groups repeated issues for the same (check, selector) pair into one suggestion', () => {
    const pageResult = {
      viewports: [
        { ...MOBILE, issues: [issueFixture('oversized-modal', 'msg a', 'div.modal')] },
        { ...DESKTOP, issues: [issueFixture('oversized-modal', 'msg b', 'div.modal')] },
      ],
    };
    const suggestions = buildFixSuggestions(pageResult);
    expect(suggestions).toHaveLength(1);
    expect(suggestions[0].brokenViewports).toHaveLength(2);
  });

  it('produces a distinct suggestion per check type, using each check\'s own fix template', () => {
    const checks = [
      'horizontal-overflow',
      'clipped-element',
      'overlapping-elements',
      'text-overflow',
      'oversized-modal',
      'overflowing-image',
      'broken-image',
    ];
    const pageResult = {
      viewports: [{ ...MOBILE, issues: checks.map((c) => issueFixture(c)) }],
    };
    const suggestions = buildFixSuggestions(pageResult);
    expect(suggestions).toHaveLength(checks.length);
    const texts = new Set(suggestions.map((s) => s.suggestion));
    expect(texts.size).toBe(checks.length); // every template is distinct
  });

  it('returns an empty array for a page with no issues at all', () => {
    const pageResult = { viewports: [{ ...MOBILE, issues: [] }, { ...DESKTOP, issues: [] }] };
    expect(buildFixSuggestions(pageResult)).toEqual([]);
  });

  it('handles a missing/malformed pageResult gracefully', () => {
    expect(buildFixSuggestions(undefined)).toEqual([]);
    expect(buildFixSuggestions({})).toEqual([]);
  });
});
