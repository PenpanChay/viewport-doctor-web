import path from 'path';
import { fileURLToPath } from 'url';
import { chromium } from 'playwright';
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { scanViewport, scanAllViewports } from '../lib/scanViewport.js';
import { startNextServer } from '../lib/nextServer.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.join(__dirname, '..');

const MOBILE = { width: 390, height: 844 };
const DESKTOP = { width: 1440, height: 900 };

describe('scanViewport (real browser, real Next.js server, no mocking)', () => {
  let nextServer;
  let baseUrl;
  let browser;

  beforeAll(async () => {
    nextServer = await startNextServer(PROJECT_ROOT);
    baseUrl = `http://localhost:${nextServer.port}`;
    browser = await chromium.launch();
  }, 30000);

  afterAll(async () => {
    await browser.close();
    await nextServer.close();
  });

  it('finds all six bug categories on the bundled demo page at a narrow (mobile) viewport', async () => {
    const { issues, screenshot } = await scanViewport(browser, `${baseUrl}/demo`, MOBILE);
    const checks = issues.map((i) => i.check);

    expect(checks).toContain('horizontal-overflow');
    expect(checks).toContain('clipped-element');
    expect(checks).toContain('overlapping-elements');
    expect(checks).toContain('text-overflow');
    expect(checks).toContain('oversized-modal');
    expect(checks).toContain('overflowing-image');

    expect(screenshot).toMatch(/^data:image\/png;base64,/);
  }, 20000);

  it('does not flag the width-dependent bugs at a wide (desktop) viewport', async () => {
    const { issues } = await scanViewport(browser, `${baseUrl}/demo`, DESKTOP);
    const checks = issues.map((i) => i.check);

    // The card row and the 900px-wide dialog both fit inside a 1440px
    // viewport, so these two specific bugs should disappear...
    expect(checks).not.toContain('horizontal-overflow');
    expect(checks).not.toContain('oversized-modal');

    // ...while the viewport-independent bugs (fixed-size clipping,
    // non-interactive-aware overlap, fixed-width text, fixed-width image)
    // are still genuinely broken regardless of screen size.
    expect(checks).toContain('clipped-element');
    expect(checks).toContain('overlapping-elements');
    expect(checks).toContain('text-overflow');
    expect(checks).toContain('overflowing-image');
  }, 20000);

  it('reports a navigationError instead of throwing when the page cannot be reached', async () => {
    const result = await scanViewport(browser, `${baseUrl}/this-route-does-not-exist-either`, MOBILE, {
      timeoutMs: 5000,
    });
    // A 404 still navigates successfully (it's a real, if unhappy, page) -
    // use an unroutable port instead to force an actual navigation failure.
    expect(result.issues).toBeDefined();

    const unreachable = await scanViewport(browser, 'http://127.0.0.1:1/', MOBILE, { timeoutMs: 3000 });
    expect(unreachable.navigationError).toBeTruthy();
    expect(unreachable.issues).toEqual([]);
  }, 15000);

  it('every issue carries a selector, a message, and a rect', async () => {
    const { issues } = await scanViewport(browser, `${baseUrl}/demo`, MOBILE);
    expect(issues.length).toBeGreaterThan(0);
    issues.forEach((issue) => {
      expect(typeof issue.check).toBe('string');
      expect(typeof issue.message).toBe('string');
      expect(typeof issue.selector).toBe('string');
      expect(issue.rect).toMatchObject({
        x: expect.any(Number),
        y: expect.any(Number),
        width: expect.any(Number),
        height: expect.any(Number),
      });
    });
  }, 20000);
});

describe('scanAllViewports (real browser, real Next.js server)', () => {
  let nextServer;
  let baseUrl;

  beforeAll(async () => {
    nextServer = await startNextServer(PROJECT_ROOT);
    baseUrl = `http://localhost:${nextServer.port}`;
  }, 30000);

  afterAll(async () => {
    await nextServer.close();
  });

  it('scans one page across multiple viewports and flattens width/height per result', async () => {
    const { pages } = await scanAllViewports({
      urls: [`${baseUrl}/demo`],
      viewports: [
        { label: 'Mobile', width: MOBILE.width, height: MOBILE.height },
        { label: 'Desktop', width: DESKTOP.width, height: DESKTOP.height },
      ],
    });

    expect(pages).toHaveLength(1);
    expect(pages[0].viewports).toHaveLength(2);

    const mobile = pages[0].viewports.find((v) => v.label === 'Mobile');
    expect(mobile.width).toBe(MOBILE.width);
    expect(mobile.height).toBe(MOBILE.height);
    expect(mobile.issues.length).toBeGreaterThan(0);

    const desktop = pages[0].viewports.find((v) => v.label === 'Desktop');
    expect(desktop.issues.some((i) => i.check === 'horizontal-overflow')).toBe(false);
  }, 30000);

  it('throws a clear error when given no URLs', async () => {
    await expect(scanAllViewports({ urls: [], viewports: [MOBILE] })).rejects.toThrow(/No URLs to scan/);
  });

  it('throws a clear error when given no viewports', async () => {
    await expect(scanAllViewports({ urls: [`${baseUrl}/demo`], viewports: [] })).rejects.toThrow(
      /No viewports to check/
    );
  }, 20000);
});
